import 'dart:io';

void main() {
  int factorial = 1;
  print("Enter Number: ");
  int num = int.parse(stdin.readLineSync()!);
  for (int i = 1; i <= num; i++) {
    factorial = factorial * i;
  }
  print(factorial);
}
