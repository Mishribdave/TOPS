import 'dart:io';

void main() {
  int a, b, add, sub, multiply;
  double div;
  print("Enter number a");
  a = int.parse(stdin.readLineSync()!);

  print("Enter number b");
  b = int.parse(stdin.readLineSync()!);

  add = a + b;
  print("Addition of two numbers is: $add");

  sub = a - b;
  print("Subtraction of two numbers is: $sub");

  multiply = a * b;
  print("Multiplication : $multiply");

  div = a / b;
  print("Division : $div");
}
