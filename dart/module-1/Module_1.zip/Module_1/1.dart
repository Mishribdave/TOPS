import 'dart:io';

void main() {
  String name, address;
  int age, birht_date;
  print("Enter your name");
  name = (stdin.readLineSync()!);

  print("Enter your Birth Date");
  birht_date = int.parse(stdin.readLineSync()!);

  print("Enter your age");
  age = int.parse(stdin.readLineSync()!);

  print("Enter your address");
  address = (stdin.readLineSync()!);
}
