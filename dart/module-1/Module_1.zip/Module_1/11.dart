import 'dart:io';

//Write a Program to check the given year is leap year or not.
void main() {
  int year;
  print("Enter a year: ");
  year = int.parse(stdin.readLineSync()!);
  if (year % 4 == 0) {
    print("Entered year is a leap year.");
  } else {
    print("Entered year is not a leap year. ");
  }
}
