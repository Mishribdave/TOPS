import 'dart:io';

void main() {
  double sum = 0;
  print("Enter Number: ");
  double num = double.parse(stdin.readLineSync()!);

  double rem;

  while (num > 0) {
    rem = num % 10;
    sum = sum + rem;
    num = num / 10;
  }
  print(sum);
}
