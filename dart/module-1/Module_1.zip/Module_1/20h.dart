import 'dart:io';

void main() {
  print("Enter Number: ");
  double num = double.parse(stdin.readLineSync()!);

  double a = 0, b = 0;

  while (num > 0) {
    a = num % 10;
    if (a > b) {
      b = a;
    }
    num = num / 10;
  }
  print(b);
}
