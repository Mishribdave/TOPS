import 'dart:io';

//Write a program to calculate sum of 5 subjects & find the percentage. Subject marks entered by user.
void main() {
  int c, java, python, os, flutter, total;
  double percentage;

  print("Enter marks of c: ");
  c = int.parse(stdin.readLineSync()!);

  print("Enter marks of java: ");
  java = int.parse(stdin.readLineSync()!);

  print("Enter marks of python: ");
  python = int.parse(stdin.readLineSync()!);

  print("Enter marks of Operating System: ");
  os = int.parse(stdin.readLineSync()!);

  print("Enter marks of flutter: ");
  flutter = int.parse(stdin.readLineSync()!);

  total = c + java + python + os + flutter;
  print("Total marks out of 500: $total");

  percentage = (total * 100) / 500;
  print("Percentage occupied is: $percentage");
}
