import 'dart:io';

void main() {
  print("Enter Three Numbers..");
  int num1 = int.parse(stdin.readLineSync()!);
  int num2 = int.parse(stdin.readLineSync()!);
  int num3 = int.parse(stdin.readLineSync()!);
  int max = (num1 > num2) ? num1 : num2;
  int result = (num3 > max) ? num3 : max;
  print("Largest=$result");
}
