import 'dart:io';

//Write a program to convert temperature from degree centigrade to Fahrenheit.
void main() {
  double celsius = 0, fahrenheit = 0;
  print("Enter temperature in celsius");
  celsius = double.parse(stdin.readLineSync()!);

  fahrenheit = (celsius * 9 / 5) + 32;
  print("Fahrenheit temperature is: $fahrenheit");
}
