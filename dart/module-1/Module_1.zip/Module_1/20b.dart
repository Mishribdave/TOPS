void main() {
  int i = 51;
  while (i <= 60) {
    print(i);
    i++;
  }
}
