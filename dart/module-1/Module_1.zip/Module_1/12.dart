import 'dart:io';

void main() {
  print("Enter Prime");
  int num = int.parse(stdin.readLineSync()!);
  int count = 0;
  for (int i = 2; i < num; i++) {
    if (num % i == 0) {
      count++;
    }
  }
  if (count == 0) {
    print("prime..");
  } else {
    print("not prime..");
  }
}
