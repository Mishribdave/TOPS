import 'dart:io';

//Write a program to make a square and cube of number.
void main() {
  int a, square, cube;

  print("Enter number a");
  a = int.parse(stdin.readLineSync()!);

  square = a * a;
  print("Square: $square");

  cube = a * a * a;
  print("CUbe : $cube");
}
