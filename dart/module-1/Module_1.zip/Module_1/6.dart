import 'dart:io';

// Write a program to find the simple Interest.
void main() {
  double p, r, n, si;

  print("Enter Principal amount");
  p = double.parse(stdin.readLineSync()!);

  print("Enter rate of interest");
  r = double.parse(stdin.readLineSync()!);

  print("Enter time");
  n = double.parse(stdin.readLineSync()!);

  si = (p * r * n) / 100;
  print("Simple Interest is: $si");
}
