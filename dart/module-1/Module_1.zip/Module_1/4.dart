import 'dart:io';

// Write a program to find the Area of Circle.
void main() {
  double radius, area, pi;

  print("Enter radius");
  radius = double.parse(stdin.readLineSync()!);
  pi = 3.14;
  area = pi * radius * radius;
  print("Area of a circle is: $area");
}
