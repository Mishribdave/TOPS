import 'dart:io';

//Write a Program to check the given number is Positive, Negative.
void main() {
  int a;
  print("Enter a number: ");
  a = int.parse(stdin.readLineSync()!);
  if (a < 0) {
    print("Entered number is a negative number");
  } else {
    print("Entered number is a positive number.");
  }
}
