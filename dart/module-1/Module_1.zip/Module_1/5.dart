import 'dart:io';

//Write a program to find the Area of Triangle.
void main() {
  double b, h, area;

  print("Enter Breadth");
  b = double.parse(stdin.readLineSync()!);

  print("Enter Height");
  h = double.parse(stdin.readLineSync()!);

  area = b * h / 2;
  print("Area of a triangle is: $area");
}
