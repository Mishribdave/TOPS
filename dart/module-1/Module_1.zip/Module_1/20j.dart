import 'dart:io';

void main() {
  print("Enter Number: ");
  double num = double.parse(stdin.readLineSync()!);

  double lastdigit;
  lastdigit = num % 10;
  while (num >= 10) {
    num = num / 10;
  }
  double firstdigit = num;
  double sum = lastdigit + firstdigit;
  print(sum);
}
