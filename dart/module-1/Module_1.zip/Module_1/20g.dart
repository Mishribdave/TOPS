import 'dart:io';

void main() {
  double rev = 0, rem;
  print("Enter Number: ");
  double num = double.parse(stdin.readLineSync()!);
  while (num > 0) {
    rem = num % 10;
    rev = rev * 10 + rem;
    num = num / 10;
  }
  print(rev);
}
